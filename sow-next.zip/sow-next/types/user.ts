import { z } from 'zod';

export const UserSchema = z.object({
  id: z.number(),
  email: z.string(),
  user_metadata: z.object({
    avatar_url: z.string(),
    full_name: z.string(),
    name: z.string(),
    nick_name: z.string(),
    give_name: z.string(),
  }),
});

export type User = z.infer<typeof UserSchema>;
