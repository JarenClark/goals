import ProtectedContent from '@/components/ProtectedContent';

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <ProtectedContent>
      <main className='container'>{children}</main>
    </ProtectedContent>
  );
}
