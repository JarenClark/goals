import { TypographyH1 } from '@/components/Typography';

export default async function DocumentsListPage() {
  return (
    <div className='py-8 mb-4'>
      <TypographyH1>SOW HOME</TypographyH1>
    </div>
  );
}
