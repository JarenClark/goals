import { NextResponse } from 'next/server';
import createRouteClient from '@/modules/supabase/createRoute';

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get('code');
  const redirectOrigin = process.env.NEXT_PUBLIC_SUPABASE_ORIGIN || origin;

  if (code) {
    const supabase = createRouteClient();
    // add error logic
    await supabase.auth.exchangeCodeForSession(code);
  }
  return NextResponse.redirect(redirectOrigin);
}
