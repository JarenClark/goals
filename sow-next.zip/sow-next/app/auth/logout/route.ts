import createServer from '@/modules/supabase/createServer';
import { NextResponse } from 'next/server';

export async function GET(request: Request) {
  const requestUrl = new URL(request.url);
  const supabase = createServer();
  const originUrl =
    process.env.NEXT_PUBLIC_SUPABASE_REDIRECT || requestUrl.origin;

  await supabase.auth.signOut();

  return NextResponse.redirect(`${originUrl}/login`, {
    status: 301,
  });
}
