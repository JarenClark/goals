import type { Metadata } from 'next';
import { fontSans } from '@/modules/font';
import ThemeProvider from '@/modules/shadcn/theme-provider';
import { cn } from '@/modules/shadcn/utils';
import '@/styles/globals.css';

export const metadata: Metadata = {
  title: 'SOW Generator',
  description: 'SOW Generator',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang='en' suppressHydrationWarning>
      <body
        className={cn(
          'min-h-screen bg-background font-sans antialiased',
          fontSans.variable
        )}
      >
        <ThemeProvider
          attribute='class'
          defaultTheme='light'
          enableSystem={false}
          disableTransitionOnChange
        >
          {children}
        </ThemeProvider>
      </body>
    </html>
  );
}
