import Image from 'next/image';
import LogoPic from '@/assets/images/sow-logo.svg';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import SignInButton from '@/components/SignInButton';

export default function Login() {
  return (
    <div className='justify-center items-center flex w-full h-screen'>
      <Card className='w-80'>
        <CardHeader className='flex flex-col items-center'>
          <Image
            className='mb-4'
            src={LogoPic}
            alt='SOW Generator Logo'
            priority={true}
            width={55}
          />
          <CardTitle>SOW Generator</CardTitle>
        </CardHeader>
        <CardContent className='flex justify-center'>
          <SignInButton />
        </CardContent>
      </Card>
    </div>
  );
}
