import createMiddleware from '@/modules/supabase/createMiddleware';
import { NextResponse, type NextRequest } from 'next/server';

export async function middleware(request: NextRequest) {
  const supabase = createMiddleware(request);
  await supabase.auth.getSession();
  return NextResponse.next();
}
