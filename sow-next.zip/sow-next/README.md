## Sow Next

## Getting Started

First, install the dependencies:

```bash
pnpm i
```

Second, run the development server:

```bash
pnpm run dev
```

To build the project:

```bash
pnpm run build
```

## Local Proxy Access

To better simulate the production environment, you can locally configure a proxy to support domain access to the application.

Locally configure the hosts file to map `dev.thatsnice.com` to the IP address `127.0.0.1`.

You can set up a local proxy using Caddy for convenient access to the application. Run the following command in the project directory:

```bash
caddy run
```

The first time, it will prompt you to enter the system password. Afterward, you can directly access the application by visiting `dev.thatsnice.com` and HTTPS is already enabled.

## Used

- Next.js
- shadcn/ui
- Supabase
- tailwindcss
- Code Formatting using ESLint, Prettier, and lint-staged

## Environment Variables

- `NEXT_PUBLIC_SUPABASE_URL`: supabase url
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`: supabase key
- `NEXT_PUBLIC_SUPABASE_ORIGIN`: your local origin url
- `NEXT_PUBLIC_SUPABASE_REDIRECT`: your app auth callback
