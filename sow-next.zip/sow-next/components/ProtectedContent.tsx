import createServer from '@/modules/supabase/createServer';
import { redirect } from 'next/navigation';

export default async function ProtectedContent({
  children,
}: {
  children: React.ReactNode;
}) {
  const supabase = createServer();
  const origin =
    process.env.NEXT_PUBLIC_SUPABASE_ORIGIN || window.location.origin;

  const {
    data: { session },
  } = await supabase.auth.getSession();

  if (!session) {
    redirect(`${origin}/login`);
  }

  return <>{children}</>;
}
