'use client';

import { Button } from '@/components/ui/button';
import createClient from '@/modules/supabase/createClient';
import { EnterIcon } from '@radix-ui/react-icons';
import { useState } from 'react';

export default function SignInButton() {
  const [loading, setLoading] = useState(false);

  const origin =
    process.env.NEXT_PUBLIC_SUPABASE_REDIRECT ||
    `${window.location.origin}/auth/callback`;

  async function signIn() {
    setLoading(true);
    const supabase = createClient();
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${origin}`,
      },
    });
    // if (error) {
    //   add error logic
    // }
    setLoading(false);
  }

  return (
    <Button onClick={signIn}>
      <EnterIcon className='mr-2 h-4 w-4' />
      Log In with Google
    </Button>
  );
}
